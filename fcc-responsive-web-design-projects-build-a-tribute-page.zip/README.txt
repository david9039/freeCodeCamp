A Pen created at CodePen.io. You can find this one at https://codepen.io/alohadave/pen/YOXobw.

 Objective: Build a CodePen.io app that is functionally similar to this: https://codepen.io/freeCodeCamp/full/zNqgVx.